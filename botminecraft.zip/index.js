 const mineflayer = require('mineflayer');

const bot = mineflayer.createBot({
  host: 'wahabb.aternos.me',  // عنوان السيرفر
  port: 25147,             // بورت السيرفر
  username: 'ADMIN',     // اسم البوت
  version: '1.17.1'        // إصدار ماين كرافت
});

// قائمة الرتب
const VIP_RANKS = ["vip", "vip+", "vip+++", "mod", "admin", "owner"];

// قائمة للكلمات السيئة
const BAD_WORDS = [
  "arse", "arsehead", "arsehole", "ass", "asshole", "bastard", "bitch",
  "bloody", "bollocks", "brotherfucker", "bugger", "bullshit", "child-fucker",
  "Christ on a bike", "Christ on a cracker", "cock", "cocksucker", "crap",
  "cunt", "dammit", "damn", "damned", "dick", "dick-head", "dickhead", "dumbass",
  "dyke", "father-fucker", "fatherfucker", "fuck", "fucker", "fucking", "god dammit",
  "god damn", "goddammit"
];

// قائمة لتتبع النقرات
let playerClicks = {};
const CPS_LIMIT = 30; // الحد الأقصى لمعدل النقرات في الثانية
const CHECK_INTERVAL = 10000; // فترة التحقق (10 ثوانٍ)

// قائمة لتتبع التحذيرات
let warnedPlayers = {};

// قائمة لتتبع الرتب
let notifiedRanks = {};

// تعيين معدل النقرات
function resetClicks() {
  playerClicks = {};
}

// التحقق من معدل النقرات
function checkCPS() {
  for (const [playerName, clickData] of Object.entries(playerClicks)) {
    const cps = clickData.clicks / (CHECK_INTERVAL / 1000);
    if (cps > CPS_LIMIT) {
      bot.chat(`/kick ${playerName} Excessive CPS detected!`);
      console.log(`${playerName} has been kicked for high CPS.`);
    }
  }
  resetClicks(); // إعادة تعيين النقرات بعد كل تحقق
}

// بدء التحقق كل فترة زمنية
setInterval(checkCPS, CHECK_INTERVAL);

// تحديث بيانات النقرات عندما يقوم اللاعب بالنقر
bot.on('playerInteract', (player) => {
  const playerName = player.username;
  if (!playerClicks[playerName]) {
    playerClicks[playerName] = { clicks: 0 };
  }
  playerClicks[playerName].clicks++;
});

// التعامل مع الرسائل الجديدة
bot.on('chat', (username, message) => {
  // التحقق من الكلمات السيئة
  if (BAD_WORDS.some(badWord => message.toLowerCase().includes(badWord))) {
    if (!warnedPlayers[username]) {
      bot.chat(`/say ${username}, watch your language!`);
      warnedPlayers[username] = true;

      setTimeout(() => {
        if (BAD_WORDS.some(badWord => message.toLowerCase().includes(badWord))) {
          bot.chat(`/mute ${username} 1h`);
          console.log(`${username} has been muted for 1 hour.`);
        }
      }, 10000); // 10 ثوانٍ للتحقق من استمرار استخدام الكلمات السيئة
    }
  }

  // التحقق من منح رتبة جديدة
  const newRank = VIP_RANKS.find(rank => message.toLowerCase().includes(rank));
  if (newRank && !notifiedRanks[username]) {
    bot.chat(`Congratulations ${username} on your new rank: ${newRank}!`);
    notifiedRanks[username] = true; // تأكيد أنه تم إرسال الرسالة فقط مرة واحدة
  }
});

// التحقق من القفز العالي
bot.on('entityMoved', (entity) => {
  if (entity.type === 'player') {
    // تحقق من وجود `position` و `oldPosition`
    if (entity.position && entity.oldPosition) {
      const jumpHeight = entity.position.y - entity.oldPosition.y;
      if (jumpHeight > 5) { // افترض أن القفز العالي هو أكثر من 5 كتل
        bot.chat(`${entity.username} is jumping too high!`);
        console.log(`Jump height: ${jumpHeight}`);
      }
    } else {
      console.warn('Entity does not have position or oldPosition.');
    }
  }
});

// حماية ضد الطيران
bot.on('entityMoved', (entity) => {
  if (entity.type === 'player') {
    const player = entity;
    const { y } = player.position;

    // افترض أن ارتفاع الطيران هو أكثر من 256
    if (y > 256) {
      bot.chat(`/kick ${player.username} Flying detected!`);
      console.log(`${player.username} has been kicked for flying.`);
    }
  }
});




// التعامل مع الأخطاء وإنهاء الجلسة
bot.on('error', (err) => {
  console.error('Error:', err);
});

bot.on('end', () => {
  console.log('Bot has ended the session.');
});